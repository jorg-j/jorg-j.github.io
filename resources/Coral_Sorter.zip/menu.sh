#!/bin/bash

t=$(mktemp -t msg.XXX) || exit
trap 'rm -r "$t"' EXIT
trap 'exit 127' HUP STOP TERM

source menu_data/sync_tools.sh

install() {
    sudo apt-get install libedgetpu1-std
    sudo apt-get install python3-pycoral
}

CHOICE=$(
    whiptail --title "Select option" --menu "Choice" 16 100 9 \
    "1" "Run Training" \
    "2" "Run Classification" \
    "3" "Sync down" \
    "4" "Sync up" \
    "5" "Clear Training Data" \
    "6" "Extraction Command" \
    3>&2 2>&1 1>&3
    )

case $CHOICE in
  "1")
  python3 imprinting_learning.py --model_path ./models/mobilenet_v1_1.0_224_l2norm_quant_edgetpu.tflite --data ./training_data --output ./models/retrained_imprinting_model.tflite
  ;;
  "2")
  python3 classify_image.py --model ./models/retrained_imprinting_model.tflite --label ./models/retrained_imprinting_model.txt
  ;;
  "3")
  syncdown
  ;;
  
  "4")
  syncup
  ;;

  "5")
  rm -r training_data/*
  ;;

  "6")
  display_fetching
  ;;

  "9")
  install
  ;;

esac
