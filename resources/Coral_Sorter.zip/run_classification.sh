python3 classify_image.py --model ./models/retrained_imprinting_model.tflite --label ./models/retrained_imprinting_model.txt
