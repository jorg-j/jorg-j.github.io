#!/usr/bin/python3



from PIL import Image
from glob import glob
import os


def naming(file):

    base_name = "f_" + os.path.basename(file)
    pathname = file.replace(os.path.basename(file), '')
    full_path = os.path.join(pathname, base_name)
    return full_path

def flip_it(filename):
    outfile = naming(filename)
    img = Image.open(filename)
    
    # flip horizontal
    flip_img = img.transpose(Image.FLIP_LEFT_RIGHT)
    
    flip_img.save(outfile)


files = glob('training_data/*/*.jpg')

for file in files:
    flip_it(file)