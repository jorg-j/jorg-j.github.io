python3 imprinting_learning.py --model_path ./models/mobilenet_v1_1.0_224_l2norm_quant_edgetpu.tflite --data ./training_data --output ./models/retrained_imprinting_model.tflite
