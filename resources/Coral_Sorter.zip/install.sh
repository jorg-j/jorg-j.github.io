sudo apt-get install libedgetpu1-std
sudo apt-get install python3-pycoral
sudo usermod -a -G dialout $USER
