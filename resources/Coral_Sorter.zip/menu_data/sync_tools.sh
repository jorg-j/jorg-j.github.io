
# Store the pi ip
check_loc() {
    FILE=menu_data/ipadd.txt
    if test -f "$FILE"; then
      tIP=$(cat "$FILE")
    else
      tIP="pi@192.168.1.1"
    fi
}

# Sync files from this device to the pi
syncdown() {
    check_loc
    DEVICE=$(whiptail --inputbox "Device address" 8 39 $tIP --title "Sync" 3>&2 2>&1 1>&3)
    echo $DEVICE > menu_data/ipadd.txt
    
    rsync -avP --exclude 'models' . $DEVICE:/home/pi/Documents/sorter --delete
}

# Sync files from the pi to this device
syncup() {
    check_loc
    DEVICE=$(whiptail --inputbox "Device address" 8 39 $tIP --title "Sync" 3>&2 2>&1 1>&3)
    echo $DEVICE > menu_data/ipadd.txt
    
    rsync -avP --exclude 'models' --exclude "feed" $DEVICE:/home/pi/Documents/sorter/ .
}

# Display on screen the required commands to pull get this data from the pi
display_fetching() {
  tIP=$(ip a | grep -oP -m1 "192.168.1.\d{3}" | grep -v 255)
  USERNAME=$(whoami)
  workingdir=$(pwd)

  whiptail --title "Run this command" --msgbox "rsync -avP $USERNAME@$tIP:$workingdir/ ." 0 0


}