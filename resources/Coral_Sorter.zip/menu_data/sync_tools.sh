# Printer which prints to cli
printlog() {
  len=${#1} # Get the length of the string

  case $2 in
    red)     col='\033[0;31m' ;;
    green)   col='\033[0;32m' ;;
    white)   col='\033[0;37m' ;;
    reset)   col='\033[0m'    ;;
    *)       col='\033[0m'    ;;
  esac
  clear='\033[0m'

  echo -e "${col}" # Set the terminal color

  perl -sE 'say "=" x $AMOUNT' -- -AMOUNT=$len
  
  echo -e "${1}"  # Print the message

  perl -sE 'say "=" x $AMOUNT' -- -AMOUNT=$len

  echo -e "${clear}" # Reset the terminal

}
# Store the pi ip
check_loc() {
    tIP=$(ip a | grep -oP -m1 "192.168.1.\d{3}" | grep -v 255)
    USERNAME=$(whoami)
    workingdir=$(pwd)

    tIP="$USERNAME@$tIP:$workingdir"

    printlog "Target Details: $tIP" "green"

}

# Sync files from this device to the pi
syncdown() {
    check_loc
    DEVICE=$(whiptail --inputbox "Device address" 8 39 $tIP --title "Sync" 3>&2 2>&1 1>&3)

    if [ -n "$DEVICE" ]; then
      rsync -avP --exclude 'models' . $DEVICE --delete
    else
      printlog "No Selection Made - Exiting" "red"
      exit
    fi
}

# Sync files from the pi to this device
syncup() {
    check_loc
    DEVICE=$(whiptail --inputbox "Device address" 8 39 $tIP --title "Sync" 3>&2 2>&1 1>&3)

    if [ -n "$DEVICE" ]; then
      rsync -avP --exclude 'models' --exclude "feed" $DEVICE .
    else
      printlog "No Selection Made - Exiting" "red"
      exit
    fi
}

# Display on screen the required commands to pull get this data from the pi
display_fetching() {
  tIP=$(ip a | grep -oP -m1 "192.168.1.\d{3}" | grep -v 255)
  USERNAME=$(whoami)
  workingdir=$(pwd)

  whiptail --title "Run this command" --msgbox "rsync -avP $USERNAME@$tIP:$workingdir/ ." 0 0


}